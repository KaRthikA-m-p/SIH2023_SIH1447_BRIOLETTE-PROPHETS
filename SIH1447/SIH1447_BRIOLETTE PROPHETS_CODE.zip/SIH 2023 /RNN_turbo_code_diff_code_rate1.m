


load combined_Turbocode_diffRates.mat
XTrain=xdata;
y_data{1,1}=categorical(ones(1,400));
y_data{2,1}=categorical(2*ones(1,600));
y_data{3,1}=categorical(3*ones(1,300));
y_data{4,1}=categorical(4*ones(1,268));
y_data{5,1}=categorical(5*ones(1,250));
y_data{6,1}=categorical(6*ones(1,240))
y_data{7,1}=categorical(7*ones(1,234))
y_data{8,1}=categorical(8*ones(1,230))



YTrain=y_data;




numFeatures = 500;
numHiddenUnits = 1500;
numClasses = 8;

layers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];
options = trainingOptions('adam', ...
    'MaxEpochs',60, ...
    'GradientThreshold',2, ...
    'Verbose',0, ...
    'Plots','training-progress');
net = trainNetwork(XTrain,YTrain,layers,options);

save rnn_net_trained_turbo_train_test.mat XTrain YTrain
save rnn_net_trained_turbo.mat net


data11=xdata{1,1};
data12=xdata{2,1};
data13=xdata{3,1};
data14=xdata{4,1};
data15=xdata{5,1};
data16=xdata{6,1};
data17=xdata{7,1};
data18=xdata{8,1};


Data22=[data11'; data12';data13';data14';data15';data16';data17';data18'];
Data22=Data22';


labels11=y_data{1,1};
labels21=y_data{2,1};
labels31=y_data{3,1};
labels41=y_data{4,1};
labels51=y_data{5,1};
labels61=y_data{6,1};
labels71=y_data{7,1};
labels81=y_data{8,1};

labels=[labels11 labels21 labels31 labels41 labels51 labels61 labels71 labels81]';

%NumberSamples=length(theclass);
NumberSamples=2522;

%Number of Training Samples
NumberTraining=floor(NumberSamples*0.65);
%Number Validation Samples
NumberValidation =floor(NumberSamples*0.20);
%Number of testing Samples
NumberTesting=floor(NumberSamples*0.15);
[ Train,Validation,Test] = GetTrainValidateTest(NumberSamples,NumberTraining,NumberValidation,NumberTesting);
%same as
%[ Train,Validation,Test] = GetTrainValidateTestPercent(NumberSamples,0.65,0.20,0.15)

Training_data=[Data22(:,Train)];
Validation_data=[Data22(:,Validation)];
Test_data=[Data22(:,Test)]; Test_data
Test_labels=[labels(Test)];

save rnn_net_trained_turbo_Train_test_val_mat_format.mat Training_data Validation_data Test_data Test_labels 
save rnn_net_trained_turbo_only_for_testing_data.mat Test_data

Y = classify(net,Test_Data);
C = confusionchart(Test_labels,Y,Title="turbo_coding with different code rates ",RowSummary="row-normalized");
% test_idx = randperm(numel(data), round(numel(data)*.2)); % 20% for test
%  train_idx = setdiff(1:numel(data), test_idx); % remaining for training

Accuracy = mean(Y == Test_labels)

for i = 1:8
    Precision(i) = C.NormalizedValues(i,i) / sum(C.NormalizedValues(i,:));
    Recall(i) = C.NormalizedValues(i,i) / sum(C.NormalizedValues(:,i));
    f1(i) = max(0,(2*Precision(i)*Recall(i)) / (Precision(i)+Recall(i)));
end

classes = unique(labels)';
classesCombined = [classes "Macro-average"];
f1Combined = [f1 mean(f1)]; 
figure
bar(classesCombined,f1Combined)

ylim([0 1])
ylabel("F1 score")
legend("Without Class Weighting","With Class Weighting")