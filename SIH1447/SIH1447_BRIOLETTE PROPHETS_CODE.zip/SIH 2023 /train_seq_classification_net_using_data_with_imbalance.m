
load WaveformData
numObservations = numel(data)
numChannels = size(data{1},1)
numClasses = numel(unique(labels))


figure
tiledlayout(2,2)
for i = 1:4
    nexttile
    stackedplot(data{i}')

    xlabel("Time Step")
    title(labels(i))
end
idxImbalanced = (labels == "Sawtooth" & rand(numObservations,1) < 0.7)...
    | (labels == "Sine")...
    | (labels == "Square"  & rand(numObservations,1) < 0.5)...
    | (labels == "Triangle" & rand(numObservations,1) < 0.3);
   
dataImbalanced = data(idxImbalanced);
labelsImbalanced = labels(idxImbalanced);

figure
histogram(labelsImbalanced)
ylabel("Class Frequency")

numObservations = numel(dataImbalanced);

[idxTrain, idxValidation, idxTest] = trainingPartitions(numObservations, [0.7 0.15 0.15]);

XTrain = dataImbalanced(idxTrain);
XValidation = dataImbalanced(idxValidation);
XTest = dataImbalanced(idxTest);

TTrain = labelsImbalanced(idxTrain);
TValidation = labelsImbalanced(idxValidation);
TTest = labelsImbalanced(idxTest);


classes = unique(labelsImbalanced)';
for i=1:numClasses
    classFrequency(i) = sum(TTrain(:) == classes(i));
    classWeights(i) = numel(XTrain)/(numClasses*classFrequency(i));
end


filterSize = 10;
numFilters = 10;

layersWeighted = [ ...
    sequenceInputLayer(numChannels,Normalization="zscore",MinLength=filterSize)
    convolution1dLayer(filterSize,numFilters)
    batchNormalizationLayer
    reluLayer
    dropoutLayer
    globalMaxPooling1dLayer
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer(Classes=classes,ClassWeights=classWeights)];

layers = layersWeighted;
layers(end).ClassWeights = "none";


options = trainingOptions("adam", ...
    MaxEpochs=500, ...
    ValidationData={XValidation, TValidation}, ...
    InitialLearnRate=0.01, ...
    SequenceLength="shortest", ...
    OutputNetwork="best-validation-loss", ...
    Verbose=false, ...
    Plots="training-progress");

netWeighted = trainNetwork(XTrain,TTrain,layersWeighted,options);
net = trainNetwork(XTrain,TTrain,layers,options);

YWeighted = classify(netWeighted, XTest);
Y = classify(net, XTest);

figure
tiledlayout(2,1)
nexttile
CWeighted = confusionchart(TTest,YWeighted, Title="With Class Weighting",RowSummary="row-normalized");
nexttile
C = confusionchart(TTest,Y, Title="Without Class Weighting",RowSummary="row-normalized");

AccuracyWeighted = mean(YWeighted == TTest)


Accuracy = mean(Y == TTest)

for i = 1:numClasses
    PrecisionWeighted(i) = CWeighted.NormalizedValues(i,i) / sum(CWeighted.NormalizedValues(i,:));
    RecallWeighted(i) = CWeighted.NormalizedValues(i,i) / sum(CWeighted.NormalizedValues(:,i));
    f1Weighted(i) = max(0,(2*PrecisionWeighted(i)*RecallWeighted(i)) / (PrecisionWeighted(i)+RecallWeighted(i)));
end

for i = 1:numClasses
    Precision(i) = C.NormalizedValues(i,i) / sum(C.NormalizedValues(i,:));
    Recall(i) = C.NormalizedValues(i,i) / sum(C.NormalizedValues(:,i));
    f1(i) = max(0,(2*Precision(i)*Recall(i)) / (Precision(i)+Recall(i)));
end



classesCombined = [classes "Macro-average"];
f1Combined = [f1 mean(f1); f1Weighted mean(f1Weighted)];

figure
bar(classesCombined,f1Combined)
ylim([0 1])
ylabel("F1 score")
legend("Without Class Weighting","With Class Weighting")