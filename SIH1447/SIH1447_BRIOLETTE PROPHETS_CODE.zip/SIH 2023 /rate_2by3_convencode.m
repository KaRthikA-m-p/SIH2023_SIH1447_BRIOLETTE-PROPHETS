M = 4;
k = log2(M);
trellis = poly2trellis([5 4],[23 35 0; 0 5 13]);
traceBack = 28;
codeRate = 2/3;
convEncoder = comm.ConvolutionalEncoder(TrellisStructure=trellis);
hMod=comm.PSKModulator(4,'BitInput',true);
hAWGN=comm.AWGNChannel('NoiseMethod','Signal to noise ratio (SNR)','SNR',10);
hDemod=comm.PSKDemodulator(4);
%ebnoVec = 0:2:10;
ebnoVec=10;
snr = convertSNR(ebnoVec,"ebno","snr", ...
    BitsPerSymbol=k, ...
    CodingRate=codeRate);
% errorStats = zeros(length(ebnoVec),3);
demodout_conv_coded_frames1=[];
for frmIdx = 1:10 
% for ii = 1:length(ebnoVec)
%     while errorStats(ii,2) <= 100 && errorStats(ii,3) <= 1e7
        dataIn = randi([0 1],10000,1);
        dataEnc = convEncoder(dataIn);
        modSignal=step(hMod,dataEnc);
        receivedsignal=step(hAWGN,modSignal);
        demodSig =step(hDemod,receivedsignal);

        % txSig = qammod(dataEnc,M, ...
        %     InputType='bit',UnitAveragePower=true);
        % rxSig = awgn(txSig,snr(ii),'measured');
        % demodSig = qamdemod(rxSig,M, ...
        %     OutputType='bit',UnitAveragePower=true);
        
        demodout_conv_coded_frames1=[demodout_conv_coded_frames1 demodSig];


        % dataOut = vitDecoder(demodSig);
        % errorStats(ii,:) = errorRate(dataIn,dataOut);
%     end
%     reset(errorRate)
% end
end

save demodout_conv_encoded_frames_file1.mat demodout_conv_coded_frames1
% berUncoded_emp = berawgn(ebnoVec','qam',M);
% spect = distspec(trellis,4)
% 
% berCoded_emp = bercoding(ebnoVec', ...
%     'conv','hard',codeRate,spect,'qam',M);
% 
% 
% semilogy(ebnoVec,errorStats(:,1),'b*', ...
%     ebnoVec,berUncoded_emp,'c-', ...
%     ebnoVec,berCoded_emp,'r')
% grid
% legend('Coded simulated','Uncoded theoretical','Coded theoretical', ...
%      'Location','southwest')
% title('16-QAM With and Without Forward Error Correction')
% xlabel('Eb/N0 (dB)')
% ylabel('Bit Error Rate')