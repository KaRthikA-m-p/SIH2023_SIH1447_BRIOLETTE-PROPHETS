clc;
clear all;
%mod = comm.DPSKModulator(BitInput=true);
snr = -10:1:10;
%demod = comm.DPSKDemodulator(BitOutput=true);
%dec = comm.BCHDecoder;
%errorRate = comm.ErrorRate(ComputationDelay=3);
N = 255;              % Codeword length
K = 239;              % Message length
S = 63;               % Shortened message length
gp = bchgenpoly(N,K); % BCH (255,239) generator polynomial
%snr = 5;
bchEncoder = comm.BCHEncoder(N,K,gp,S);
  data = randi([0 1],630,1); 

for k = 1:length(snr)
  encodedData = bchEncoder(data);            % BCH encode data
  modSignal = qammod(encodedData,64);         % BPSK modulate
  receivedSignal = awgn(modSignal,snr(k));      % Pass through AWGN channel
  demodSignal(:,k) = qamdemod(receivedSignal,64);  % BPSK demodulate
  % receivedBits = bchDecoder(demodSignal);    % BCH decode data
  % errorStats = errorRate(data,receivedBits); % Compute error statistics
end
save bchdemod.mat demodSignal data;
