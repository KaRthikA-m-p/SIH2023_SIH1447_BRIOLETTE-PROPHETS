N = [32;32];
K = [21;26];
S = [19;24];
msg = randi([0 1],prod(S),1);
code = tpcenc(msg,N,K,S);
M = 4;
snr = 3;
demod_tpc_QPSK=[];
for i=1:500
txsig = qammod(code,M,'InputType','bit', ...
    'UnitAveragePower',true);

rxsig = awgn(txsig,snr,'measured');

llr = qamdemod(rxsig,M,'OutputType','approxllr', ...
    'UnitAveragePower',true,'NoiseVariance',10.^(-snr/10));
demod_tpc_QPSK=[demod_tpc_QPSK llr];
end
save demod_tpc_QPSK_file.mat demod_tpc_QPSK
