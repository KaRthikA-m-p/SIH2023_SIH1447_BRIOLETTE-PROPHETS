



frameLen = 25*8;            % Payload length in bits
r = "3/4";
permParams = [19 13 2 9 15];

snrdB = 10;                  % SNR
nVar = 10.^(-snrdB/10);     % Noise variance
errorRate = comm.ErrorRate; % Calculates BER


demodout_turbo_coded_frames=[];
for frmIdx = 1:10 
    msg = randi([0 1],frameLen,1);
    code = dvbrcs2TurboEncode(msg,r,permParams);
    modCode = qammod(code,4,[0 2 3 1], ...
                 'InputType','bit', ...
                 'UnitAveragePower',true);         % QPSK Modulation
    receivedOut = awgn(modCode, snrdB);
    demodOut = qamdemod(receivedOut,4,[0 2 3 1], ...
                 'OutputType','llr', ...
                 'UnitAveragePower',true, ...
                 'NoiseVariance',nVar);            % QPSK Demodulation
    demodout_turbo_coded_frames=[demodout_turbo_coded_frames demodOut];
    decoded = dvbrcs2TurboDecode(-1*demodOut,r, ...
                                permParams);
 errorStats = errorRate(int8(msg),decoded);
end
save  demodout_turbo_coded_frames_file.mat  demodout_turbo_coded_frames

