

XTrain=xdata;
y_data{1,1}=categorical(ones(1,1089));
y_data{2,1}=categorical(2*ones(1,2457));
y_data{3,1}=categorical(3*ones(1,621));

YTrain=y_data;

% figure
% for j = 1:numel(classes)
%     label = classes(j);
%     idx = find(YTrain{1} == label);
%     hold on
%     plot(idx,X(idx))
% end
% hold off

% xlabel("Time Step")
% ylabel("Acceleration")
% title("Training Sequence 1, Feature 1")
% legend(classes,'Location','northwest')
numFeatures = 500;
numHiddenUnits = 1500;
numClasses = 3;

layers = [ ...
    sequenceInputLayer(numFeatures)
    lstmLayer(numHiddenUnits,'OutputMode','sequence')
    fullyConnectedLayer(numClasses)
    softmaxLayer
    classificationLayer];
options = trainingOptions('adam', ...
    'MaxEpochs',60, ...
    'GradientThreshold',2, ...
    'Verbose',0, ...
    'Plots','training-progress');
net = trainNetwork(XTrain,YTrain,layers,options);


% load HumanActivityTest
% figure
% plot(XTest{1}')
% xlabel("Time Step")
% legend("Feature " + (1:numFeatures))
% title("Test Data")
% YPred = classify(net,XTest{1});
% accumarray=sum(YPred == YTest{1})./numel(YTest{1})
% figure
% plot(YPred,'.-')
% hold on
% plot(YTest{1})
% hold off
% xlabel("Time Step")
% ylabel("Activity")
% title("Predicted Activities")
% legend(["Predicted" "Test Data"])