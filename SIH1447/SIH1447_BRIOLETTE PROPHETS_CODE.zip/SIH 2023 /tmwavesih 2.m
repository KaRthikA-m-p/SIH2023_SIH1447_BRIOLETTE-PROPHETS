clc;
clear all;

tmWaveGen = ccsdsTMWaveformGenerator;
tmWaveGen.WaveformSource = "synchronization and channel coding";



%tmWaveGen.NumBitsInInformationBlock = 1024;
tmWaveGen.Modulation = "QPSK";
% tmWaveGen.CodeRate = "1/2";
% disp(tmWaveGen)



%%%%%%%%%%%%%%%%%
% BW = 36e6;     % Typical satellite channel bandwidth
% Fsamp = tmWaveGen.SamplesPerSymbol*BW;
% scope = spectrumAnalyzer('SampleRate',Fsamp,...
%                              'AveragingMethod','Exponential');
% scope(waveform)
%%%%%%%%%%%%%%%%%
% SNR=-10:2:10;
SNR=[-10 30];

for i=1:2
    load dnnet.mat;
    tmWaveGen.ChannelCoding = "convolutional";
    numTF = 15;
    waveform = [];
    % rng default    % For reproducible results
    for iTF = 1:numTF
        bits = randi([0 1],tmWaveGen.NumInputBits,1);
        waveform = [waveform; tmWaveGen(bits)];
    end
    rx = awgn(waveform, SNR(i));
    demodobj = HelperCCSDSTMDemodulator("Modulation","QPSK","ChannelCoding","convolutional");
    demodData_conv = demodobj(rx);

    release(tmWaveGen);
    % tmWaveGen = ccsdsTMWaveformGenerator;
    % tmWaveGen.WaveformSource = "synchronization and channel coding";
    % tmWaveGen.Modulation = "QPSK";
    tmWaveGen.ChannelCoding = "LDPC";
    numTF = 15;
    waveform = [];
    % rng default    % For reproducible results
    for iTF = 1:numTF
        bits = randi([0 1],tmWaveGen.NumInputBits,1);
        waveform = [waveform; tmWaveGen(bits)];
    end
    rx = awgn(waveform, SNR(i));
    demodobj = HelperCCSDSTMDemodulator("Modulation","QPSK","ChannelCoding","LDPC");
    demodData_LDPC = demodobj(rx);
    release(tmWaveGen);
    tmWaveGen = ccsdsTMWaveformGenerator;
    tmWaveGen.WaveformSource = "synchronization and channel coding";
    tmWaveGen.Modulation = "QPSK";
    tmWaveGen.ChannelCoding = "RS";
    numTF = 15;
    waveform = [];
    % rng default    % For reproducible results
    for iTF = 1:numTF
        bits = randi([0 1],tmWaveGen.NumInputBits,1);
        waveform = [waveform; tmWaveGen(bits)];
    end
    rx = awgn(waveform, SNR(i));
    demodobj = HelperCCSDSTMDemodulator("Modulation","QPSK","ChannelCoding","RS");
    demodData_RS= demodobj(rx);

    release(tmWaveGen);
    tmWaveGen = ccsdsTMWaveformGenerator;
    tmWaveGen.WaveformSource = "synchronization and channel coding";
    tmWaveGen.Modulation = "QPSK";
    tmWaveGen.ChannelCoding = "turbo";
    numTF = 15;
    waveform = [];
    % rng default    % For reproducible results
    for iTF = 1:numTF
        bits = randi([0 1],tmWaveGen.NumInputBits,1);
        waveform = [waveform; tmWaveGen(bits)];
    end
    rx = awgn(waveform, SNR(i));
    demodobj = HelperCCSDSTMDemodulator("Modulation","QPSK","ChannelCoding","turbo");
    demodData_turbo = demodobj(rx);
    release(tmWaveGen);
    NF=floor(size(demodData_conv,1)/500);
    xdata_conv=resize(demodData_conv,[NF 500]);

    NF=floor(size(demodData_LDPC,1)/500);
    xdata_LDPC=resize(demodData_LDPC,[NF 500]);

    NF=floor(size(demodData_RS,1)/500);
    xdata_RS=resize(demodData_RS,[NF 500]);

    NF=floor(size(demodData_turbo,1)/500);
    xdata_turbo=resize(demodData_turbo,[NF 500]);
    xdata={};
    xdata{1,1}=xdata_conv';
    xdata{2,1}=xdata_LDPC';
    xdata{3,1}=xdata_RS';
    xdata{4,1}=xdata_turbo';
    ydata=categorical([1;2;3;4]);
    xtest=xdata;
    ytest=ydata;
    miniBatchSize = 27;
    options = trainingOptions('adam', ...
        'ExecutionEnvironment','auto', ...
        'MaxEpochs',50, ...
        'MiniBatchSize',miniBatchSize, ...
        'ValidationData',{xtest,ytest}, ...
        'GradientThreshold',2, ...
        'Shuffle','every-epoch', ...
        'Verbose',false, ...
        'Plots','training-progress');

    net = trainNetwork(xdata,ydata,layers_2,options);
    YPred = classify(net,xtest,'MiniBatchSize',miniBatchSize);
    acc(i) = mean(YPred == ytest);
    i

end
SNR
acc
%demodData_conv = demodobj(rx);
% save demod_conv.mat demodData_conv;
% demodData_LDPC = demodobj(rx);
% save demod_LDPC.mat demodData_LDPC;

% demodData_RS = demodobj(rx);
% save demod_RS.mat demodData_RS;

% demodData_turbo = demodobj(rx);
% save demod_turbo.mat demodData_turbo;

%%%%%%%%%%%%%%%%%
% BW = 36e6;     % Typical satellite channel bandwidth
% Fsamp = tmWaveGen.SamplesPerSymbol*BW;
% scope = spectrumAnalyzer('SampleRate',Fsamp,...
%                              'AveragingMethod','Exponential');
% scope(demodData_turbo)
%%%%%%%%%%%%%%%%%




% ydata_conv=ones(size(xdata_conv,1),1);
%
% ydata_LDPC=2*ones(size(xdata_LDPC,1),1);
%
% ydata_RS=3*ones(size(xdata_RS,1),1);
%
% ydata_turbo=4*ones(size(xdata_turbo,1),1);


% data=[xdata ydata];


% t=randi(8470,8000,1);
% tt=randi(8470,400,1);
%
% xtrain=data(t,1:end-1);
% ytrain=data(t,end);
% ytrain=categorical(ytrain);
% xtest=data(tt,1:end-1);
% ytest=data(tt,end);








% Example usage:


% Generate a received signal with an SNR of 10 dB.
% received_signal = generate_received_signal(10);

% Recognize the type of FEC code used to encode the transmitted signal.
% fec_type = fec_recognition(received_signal);

% Print the type of FEC code.
% disp(fec_type);



% channelCoding = "convolutional"; % Channel coding scheme
% transferFrameLength = 1115;      % In bytes corresponding to 223*5
% modScheme = "QPSK";              % Modulation scheme
% alpha = 0.35;                    % Root raised cosine filter roll-off factor
% sps = 8;
% fSym = 2e6; % Symbol rate or Baud rate in Hz
% cfo = 2e5;  % In Hz
% EbN0 = 10;
% tmWaveGen = ccsdsTMWaveformGenerator("ChannelCoding",channelCoding, ...
%     "NumBytesInTransferFrame",transferFrameLength, ...
%     "Modulation",modScheme, ...
%     "RolloffFactor",alpha, ...
%     "SamplesPerSymbol",sps);
% disp(tmWaveGen)
% rate = tmWaveGen.info.ActualCodeRate;
% M = tmWaveGen.info.NumBitsPerSymbol;
% numBitsInTF = tmWaveGen.NumInputBits;
% % snr = EbN0 + 10*log10(rate) + ...
% %     10*log10(M) - 10*log10(sps);      % As signal power is scaled to one while introducing noise,
%                                       % SNR value should be reduced by a factor of SPS
% numSNR = length(snr);
% ber = zeros(numSNR,1);                % Initialize the BER parameter
% bercalc = comm.ErrorRate;
% msg = [de2bi(mod(tfidx-1,numMessagesInBlock),numBitsForBER,"left-msb").';bits];