function [ Train,Validation,Test] = GetTrainValidateTestPercent(NumberSamples,PercentTraining,PercentValidation,PercentTesting)
% this function randomly partitions data into training, validation and testing data using Cross Validation. partitioning data in this manner is commonly used for determining the performance of algorithms with free parameters.
%Training data is commonly used to train the system, the optimum value for the free parameters are determined using validation data.
%Finally the results of the algorithm determined using testing data .This function is different than Matlab in that you enter percentage of total data used for each set. All the data is used in this version.  The percentage of data used in testing is the leftovers of all the data used. Let PDUT Percentage of data used in testing, the percentage of data used in testing is given by:  
%PDUT=1-PercentTraining-PercentValidation
%Input%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NumberSamples: number of samples in your data set
%PercentTraining: Percent of NumberSamples used as training examples
%PercentValidation: Percent of NumberSamples used as validation examples
%PercentTesting:Percent of NumberSamples used as testing examples
%such that :1> PercentTraining> PercentValidation>PercentTesting>0
%Output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%Train: Logical index column vectors for training data
%Validation:  Logical index column vectors for validation data
%Test:  Logical index column vectors for testing data

NumberTraining=floor(NumberSamples*PercentTraining);
NumberValidation=floor(NumberSamples*PercentValidation);
NumberTesting=floor(NumberSamples*PercentTesting);
% Initialize ouput variables  
% Initialize ouput variables  
Train=zeros(NumberSamples,1);
Validation=zeros(NumberSamples,1);
Test=zeros(NumberSamples,1);
%Proportion of training data
TrainProportion= (1-NumberTraining/NumberSamples);
%Partition data into training and other, then partition Other into validation and testing data, other is just a dummy variable
%Other={ validation, test}
[Train, Othere] = crossvalind('HoldOut', NumberSamples,TrainProportion);
%index of data points in other
IndexOthere=find(Othere==1);
%Number of data points used for training and testing
SizeOthere=length(IndexOthere);
%Proportion of data in the set other used in validation
ValidationProportion=NumberTesting/NumberValidation;
%Partition into Validation data and testing data
[ValidationDummy ,TestDummy]=crossvalind('HoldOut', SizeOthere,ValidationProportion);
%logical index vectors for validation data
Validation(IndexOthere(ValidationDummy))=1;
% logical index vectors for test data
Test(IndexOthere(TestDummy))=1;
Validation=logical(Validation);
Test=logical(Test);
end
