crc32Generator = comm.CRCGenerator(...
    Polynomial="x^32+x^29+x^18+x^14+x^3+1", ...
    InitialConditions=1);
infoSize = 7526;                            % Information block size without CRC
m = 6;
M = 2^m;               
Ts = 32;                                    % PPM slot width in nanoseconds
pps = linspace(-30.25,-29.88,7)';           % Average number of signal photons per nano second (ns/(M*Ts))
ns = power(10,pps/10)*M*Ts;                 % Average number of signal photons per pulsed slot
nb = 0.2;                                   % Average number of noise photons per slot

% Initialize Poisson channel System object
chanObj = dsocPoissonChannel(NumNoisePhotons=nb);
numFrames = 20;
numErrFrames = zeros(length(ns),1);
berEst = zeros(length(ns),1);
errorRate = comm.ErrorRate;

for itr = 1:length(ns)
    rng("default")
    chanObj.NumSignalPhotons=ns(itr);
    for frmIdx=1:numFrames
        % Generate input data
        data = randi([0 1],infoSize,1);
        crcData = crc32Generator(data);     % Generate CRC
        msgIn = [crcData; 0; 0];            % Add termination bits

        % Perform SCPPM encoding
        [encSym,info] = ccsdsSCPPMEncode(msgIn,m);
        r = info.OuterEncoderCodeRate;              

        % M-ary PPM Modulation
        modOut = zeros(length(encSym)*M,1);
        mapIndex = (0:length(encSym)-1)'*M + encSym + 1;
        modOut(mapIndex) = 1;

        % Pass through Poisson channel
        slotCount = chanObj(modOut);                 
        receivedCode = log(1+(ns(itr)/nb))*slotCount - ns(itr);

        % SCPPM decoding
        [decData,errFrames] = ccsdsSCPPMDecode(...
            receivedCode,r,m);                       
        errorStats = errorRate(int8(msgIn),decData);
        numErrFrames(itr) = numErrFrames(itr)+errFrames;
    end
    berEst(itr) = errorStats(1);
    release(errorRate)
    release(chanObj)
end
semilogy(pps,berEst,'-*')
xlabel("Signal photons per nano second (ns/(M*Ts)) in dB photons/ns")
ylabel("Bit Error Rate")
title(['BER results for infoSize=',num2str(infoSize),',m=',num2str(m),',nb=',num2str(nb),',Ts=',num2str(Ts),'ns'])
