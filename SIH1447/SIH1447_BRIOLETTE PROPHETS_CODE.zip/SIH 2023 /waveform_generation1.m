wave_out = cell(1);
for k = 1:5 % specify how many samples you want
    cfgHESU = wlanHESUConfig;
    bits = randi([0 1],1,4);
    osf = 2;
    
    waveformHESU = wlanWaveformGenerator(bits,cfgHESU, ...
        NumPackets=1,IdleTime=15e-6, ...
        OversamplingFactor=osf);
    
    fsHESU = wlanSampleRate(cfgHESU.ChannelBandwidth);
    time = (0:length(waveformHESU)-1)/fsHESU;
    wave_out{k} = [time; abs(waveformHESU')];
end