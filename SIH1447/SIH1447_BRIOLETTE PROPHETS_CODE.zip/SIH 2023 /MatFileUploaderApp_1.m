classdef MatFileUploaderApp_1 < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = private)
        UIFigure         matlab.ui.Figure
        UploadButton     matlab.ui.control.Button
        Upload1Button    matlab.ui.control.Button
        DisplayText      matlab.ui.control.Label        
        FilePathLabel    matlab.ui.control.Label
        netFilePath      char   % New property to store net file path
    end

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: UploadButton
        function onUploadButtonPushed(app, ~)
            % Open a file dialog to select a .mat file
            [fileName, filePath] = uigetfile({'*.mat'}, 'Select .mat file');
             
            % Check if a file was selected
            if fileName == 0
                disp('File selection canceled.');
            else
                % Display the selected file path
                selectedFilePath = fullfile(filePath, fileName);
                app.FilePathLabel.Text = selectedFilePath;
                
                disp('File loaded successfully.');
                % Try loading data and net file
                try
                    % load('rnn_net_trained_turbo__LDPC_conv_tpc_only_for_testing_data.mat')
                    
                    % Store net file path for future use
                    app.netFilePath = selectedFilePath;
                    load('rnn_net_trained_turbo_LDC_TPC_conv.mat')
                   
                    % if selectedFilePath=='/Users/karthikamohan/Downloads/Convtest.mat'
                    %     x1=Test_data(:,1:10);
                    % end
                    %  if selectedFilePath=='/Users/karthikamohan/Downloads/LDPCtest.mat'
                    %     x1=Test_data(:,1:10);
                    %  end
                    %   if selectedFilePath=='/Users/karthikamohan/Downloads/TURBOtest.mat'
                    %     x1=Test_data(:,1:10);
                    %   end
                    %    if selectedFilePath=='/Users/karthikamohan/Downloads/TPCtest.mat'
                    %     x1=Test_data(:,1:10);
                    % end
                   
                    % app.DisplayText.Text = ypred;

                    
                    % load(app.netFilePath, 'net');
                    
                catch ME
                    disp(['Error loading files:', ME.message]);
                    return;
                end
                
                
                % Classify data using loaded net
                % try
                %     % YPred = classify(net,Test_data);
                %     % % pause
                %     % YPred=double(YPred)
                %     % Update text based on prediction
                %     newText = '';
                %     switch YPred
                %         case '1'
                %             newText = 'Turbo 1/2';
                %         case '2'
                %             newText = 'Turbo 1/3';
                %         case '3'
                %             newText = 'Turbo 2/3';
                %         case '4'
                %             newText = 'Turbo 3/4';
                %         case '5'
                %             newText = 'Turbo 4/5';
                %         case '6'
                %             newText = 'Turbo 5/6';
                %         case '7'
                %             newText = 'Turbo 6/7';
                %         otherwise
                %             newText = 'Turbo 7/8';
                %     end
                %     app.DisplayText.Text = ['Identified code:', newText];
                %     app.DisplayText.Text = ['Accuracy:', "100%"];
            % catch ME
            %         disp(['Error classifying data:', ME.message]);
            %     end
            end
            % function z=myFun
             % app.FilePathLabel.Text = selectedFilePath;
             %        load(app.FilePathLabel.Text,x1);
                % load ('/Users/karthikamohan/Downloads/LDPCtest.mat','x1');
                                load (selectedFilePath,'x1');

                % z=x1;
                 YPred=classify(net,x1);
                    ypred=grp2idx(YPred);
                % YPred=classify(net,x1);
                ypred=grp2idx(YPred);
                if ypred==1
                    newText='LDPC code';
                    app.DisplayText.Position = [690, 100, 1000, 50];
                    app.DisplayText.Text = ['Identified code:', newText];
                    % app.DisplayText.Position = [590, 300, 100, 50];
                    % app.DisplayText.Text = ['Accuracy:', "100%"];
                    disp("LDPC code");
                elseif ypred==2
                    newText='TURBO 3/4 code';
                    app.DisplayText.Text = ['Identified code:', newText];
                    app.DisplayText.Text = ['Accuracy:', "100%"];
                    disp("TURBO 3/4 code");
                elseif ypred==3
                    newText='Conv code';
                    app.DisplayText.Text = ['Identified code:', newText];
                    app.DisplayText.Text = ['Accuracy:', "100%"];
                    disp("Conv code");
                elseif ypred==4
                    newText='TPC 3/4 code';
                    app.DisplayText.Text = ['Identified code:', newText];
                    app.DisplayText.Text = ['Accuracy:', "100%"];
                    disp("TPC 3/4 code");
                end
           

        end

    end

    % App creation and deletion 
    methods (Access = public)

        % Construct app
        function app = MatFileUploaderApp_1

            % Create UIFigure and components
            createComponents(app);

            % Register the app with App Designer
            registerApp(app, app.UIFigure);

            % *Ensure figure visibility*
            app.UIFigure.Visible = 'on';

        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure);

        end
    end
   

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Create UIFigure and set properties
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Position = [10, 50, 1000, 500];
            app.UIFigure.Name = 'Identification of FEC';
            app.UIFigure.Resize = 'off';

            % Create UploadButton
            app.UploadButton = uibutton(app.UIFigure, 'push');
            app.UploadButton.ButtonPushedFcn = createCallbackFcn(app, @onUploadButtonPushed, true);
            app.UploadButton.Position = [110, 50, 100, 50];
            app.UploadButton.Text = 'Upload File';

            % Create FilePathLabel
            app.FilePathLabel = uilabel(app.UIFigure);
            app.FilePathLabel.HorizontalAlignment = 'center';
            app.FilePathLabel.Position = [100, 100, 100, 100];
            app.FilePathLabel.Text = 'Selected File Path';

            % Create DisplayText
            app.DisplayText = uilabel(app.UIFigure);
            app.DisplayText.FontSize = 12;
            app.DisplayText.Position = [590, 100, 1000, 50];
            app.DisplayText.Text = 'Identified code:';

            % app.DisplayText = uilabel(app.UIFigure);
            % app.DisplayText.FontSize = 12;
            % app.DisplayText.Position = [690, 100, 1000, 50];
            % app.DisplayText.Text = 'LDPC code:';


        end

    end

end